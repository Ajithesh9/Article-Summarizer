import linkIcon from './link.svg'
import loader from './loader.svg'
import copy from './copy.svg'
import logo1 from './logo1.svg'
import tick from './tick.svg'

export {
    linkIcon,
    loader,
    copy,
    logo1,
    tick
}